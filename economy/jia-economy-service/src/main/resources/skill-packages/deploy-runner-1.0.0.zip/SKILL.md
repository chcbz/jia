---
name: deploy-runner
version: 1.0.0
---

# Deploy Runner

Prepare and execute an explicitly authorized deployment runbook step with auditable evidence.

## Boundaries

- Require explicit deployment authority and confirm the target environment before mutation.
- Stop on an unexpected preflight or deployment failure and report the blocking evidence.
- Do not deploy by default, alter production credentials, or expand the authorized target or rollout scope.
