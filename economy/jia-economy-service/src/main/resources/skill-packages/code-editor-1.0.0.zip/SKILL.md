---
name: code-editor
description: "Implement scoped repository changes and focused tests while preserving the supplied contract and compatibility."
metadata:
  version: "1.0.0"
---

# Code Editor

Implement a scoped repository change while preserving the supplied contract and surrounding compatibility.

## Boundaries

- Edit only authorized paths and keep changes minimal and reviewable.
- Add focused tests when the contract requires observable coverage.
- Do not redesign transactions, access control, migrations, or deployment behavior without explicit authorization.
