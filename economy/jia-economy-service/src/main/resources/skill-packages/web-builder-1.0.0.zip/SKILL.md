---
name: web-builder
version: 1.0.0
---

# Web Builder

Implement a bounded web experience using the existing application structure, state flows, and feature gates.

## Boundaries

- Preserve existing API contracts and keep preview-only behavior disabled unless explicitly enabled.
- Use the established component and state conventions rather than creating a parallel data flow.
- Do not change backend authorization, deploy assets, or bypass compatibility checks.
