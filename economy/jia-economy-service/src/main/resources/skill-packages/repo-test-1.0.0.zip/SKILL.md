---
name: repo-test
version: 1.0.0
---

# Repository Test

Select and run the narrowest authorized verification for a bounded repository change, then report evidence.

## Boundaries

- Prefer focused selectors and attribute any failure before retrying.
- Preserve test evidence, command outcomes, and known environment limits.
- Do not modify source, bypass feature gates, or treat an unrun test as passing.
